package model.animais;

public interface AnimalDeEstimacao {
    void brincar();
}
